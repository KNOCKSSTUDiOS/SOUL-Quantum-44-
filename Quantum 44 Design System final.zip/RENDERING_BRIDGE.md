# Q44 · Rendering Bridge

A platform-neutral specification for keeping the **Astro Noir / Quantum Teal
SSS** material visually identical from a 5" phone to a 360° immersive
workspace.

## Goal — visual continuity

One source of truth for the **o-ring SSS shader**. The shader is compiled to
each platform's native graphics API, but every implementation MUST produce a
pixel-equivalent SSS read at any given (depth, sss, env) tuple.

| Surface | Engine | Shader pipeline | Color space |
| --- | --- | --- | --- |
| Web (console) | CanvasKit (WASM) → WebGL2 | GLSL ES 3.0 | Display P3 → sRGB |
| iOS app       | CanvasKit (mobile) → Metal | MSL 2.4 (translated)        | Display P3 |
| Android app   | CanvasKit (mobile) → Vulkan | SPIR-V (translated)         | Display P3 |
| VR / 360°     | OpenXR → CanvasKit Skybox    | GLSL ES 3.2 + cubemap         | scRGB (linear) |

CanvasKit is the **single rendering frontend**. It serves a single Skia
PictureRecord for every Q44 surface; platform back-ends translate that record
to Metal (iOS) or Vulkan (Android) via Skia's existing back-ends. No
hand-ported shaders per platform.

## The O-Ring SSS shader (canonical)

The shader takes one ring + four uniforms:

```
uniform vec3  uTop;     // ring top color
uniform vec3  uMid;     // ring mid color
uniform vec3  uBot;     // ring bottom color
uniform vec3  uCaustic; // SSS bleed color (accent)
uniform float uDepth;   // 0..1, neural depth (drives rim sharpness)
uniform float uSSS;     // 0..1, subsurface scattering amount
uniform vec2  uPos;     // pixel position
uniform float uRadius;  // ring outer radius
```

Output is the sum of:

1. **Body gradient** — `mix(uBot, mix(uMid, uTop, smoothstep(0., 1., y)), …)`
2. **Rim highlight** — `pow(1. - dist / uRadius, 12. * uDepth)`
3. **Inner shadow** — `pow(dist / uRadius, 14.)`
4. **Caustic bleed** — `uCaustic * uSSS * exp(-distBelow * 0.04)`

The `uDepth` value (44 / 64 = `0.6875`) is the shipped default for Q44;
shipping any other value violates "Quantum 44" branding.

## 2D → 360° transition

The console adapts its workspace based on detected display:

- **2D (mobile / desktop):** standard React layout. Sidebar 260px (desktop),
  bottom-tab on mobile. Viewport letterboxed at 2.39:1.
- **Immersive (VR / OpenXR detected):** the `Cosmic Void` workspace.
  Sidebar dissolves into floating o-ring tiles arranged on a 270° arc;
  viewport detaches from the page and renders as a free-floating SSS slab in
  noir-cubemap space; reels orbit on a horizontal carousel at hip height.

The transition is **a single non-skippable cinematic** — `--ease-cine` over
`720ms`, with grain ramp and scanline collapse. There is no "skip animation"
preference; the transition IS the brand.

## Detection

```js
const headset = await navigator.xr?.isSessionSupported('immersive-vr');
if (headset) document.documentElement.dataset.q44Mode = 'cosmic';
else         document.documentElement.dataset.q44Mode = '2d';
```

CSS keys off `[data-q44-mode]` to swap layout tokens. Shader uniforms do
**not** change between modes — the material is identical.

## Open questions

- VR ergonomics for the knob component — currently optimised for mouse drag.
  Hand-tracked grab-and-twist would feel more cinematic; needs prototyping.
- Color volume: Display P3 → scRGB conversion clips Plasma Orchid above
  ~`#A65BE0` on standard HDR headsets. Either re-master orchid as a
  spectral curve or accept the clip.
- Audio is out of scope of *this* document but the cinematic transition needs
  a designed sound — flag for the audio team.
