---
name: knocksstudios-q44-design
description: Use this skill to generate well-branded interfaces and assets for KNOCKSSTUDiOS Hollywood MOTiON Pictures — Soul (Quantum 44), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files. Specifically: `colors_and_type.css` (the single source of truth — tokens, type, **o-ring SSS** material, motion), `assets/` (logo + wordmark), `ui_kits/soul-engine/` (working console UI kit with Chrome, Console, and an interactive index.html), and `preview/` (foundation cards).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Always link `colors_and_type.css` (or inline its tokens) and use the `.q-oring` material — combined with `--noir / --teal / --orchid / --ghost` — for any signature interactive element. Buttons, knobs, toggles, primary cards: o-ring. Backgrounds: Astro Noir + faint magnetic grid + film-grain noise + corner ticks. Type: Orbitron uppercase for display, Space Grotesk for body, JetBrains Mono for engineering. Never use emoji.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, surface — Intro / HUD / Outro, Astro Noir / Teal / Orchid emphasis, level of cinematic-vs-functional), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
