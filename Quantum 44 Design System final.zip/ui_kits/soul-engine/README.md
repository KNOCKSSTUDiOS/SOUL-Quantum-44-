# Soul Engine Console — UI kit

Production console for the Q44 Soul Engine. The kit is composed of small JSX
components mounted by `index.html`. They share the foundation tokens in
`../../colors_and_type.css`.

## Files

- `index.html` — wires Sidebar, Topbar, Viewport, StatRail, ReelList, SoulPanel into a working console layout. Includes a live-updating render scrubber and an interactive knob/toggle panel.
- `Chrome.jsx` — `Sidebar`, `Topbar`. Fixed nav with active rail, pipeline tile, user identity. Topbar has eyebrow + display title + REC pill + ghost/teal o-ring buttons.
- `Console.jsx` — `Viewport` (canvas-driven cinematic frame with corner ticks, REC dot, scanline sweep, scrub bar), `StatRail` (4 stat cells), `ReelList` (status chips: render/soul/idle/fault).

## Visual conventions used

- All buttons use the `.q-oring` material with a `--noir / --teal / --orchid / --ghost` modifier.
- Eyebrow text is mono, 0.32em tracking, Quantum Teal.
- Headings are Orbitron, uppercase, 0.06em+ tracking.
- Panels: gradient noir surface → inner rim highlight → 1px hairline border + soft drop.
- Status colors:
  - Render = Quantum Teal
  - Soul = Plasma Orchid
  - Sync = #4ADE80 (sparingly)
  - Drift = #F5A524
  - Fault = #F43F5E

## Coverage

Pixel-fidelity recreations are limited to a single console screen (Render). The
kit deliberately does **not** include marketing-site or login/settings flows —
the brief specifies a studio engine product, not a public site.

If additional surfaces are needed (login, project chooser, archive browser),
extend the kit in this folder rather than starting a new one. Re-use the
foundation classes; do not invent new colors.
