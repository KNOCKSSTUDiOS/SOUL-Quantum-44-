/* global React */
const { useState, useEffect, useRef } = React;

// ============================================================
// Subscriber Vault — tiered gallery + privacy toggle + Air Radio
// ============================================================

const TIERS = {
  free:       { label: 'Free',       max: '1080p',  color: '#B7B7C2', accent: 'rgba(255,255,255,0.06)' },
  regular:    { label: 'Regular',    max: '2K',     color: '#7DDCEE', accent: 'rgba(0,180,216,0.18)' },
  business:   { label: 'Business',   max: '4K',     color: '#D4A8F0', accent: 'rgba(123,44,191,0.22)' },
  enterprise: { label: 'Enterprise', max: '8K',     color: '#6FFFE9', accent: 'rgba(111,255,233,0.22)' },
};
const TIER_ORDER = ['free','regular','business','enterprise'];

const ASSETS = [
  { id: '0044_soul',     name: 'reel · 0044 · soul',     tier: 'enterprise', priv: false, hue: '#7B2CBF', meta: '8K · 44b · sss 0.86' },
  { id: '0043_orchid',   name: 'reel · 0043 · orchid',   tier: 'business',   priv: true,  hue: '#A65BE0', meta: '4K · 44b · graded'    },
  { id: '0042_noir',     name: 'reel · 0042 · noir',     tier: 'regular',    priv: false, hue: '#34343B', meta: '2K · 44b · archived'  },
  { id: '0041_meltdown', name: 'reel · 0041 · meltdown', tier: 'enterprise', priv: true,  hue: '#F43F5E', meta: '8K · 44b · marquee'   },
  { id: '0040_lava',     name: 'reel · 0040 · lava',     tier: 'business',   priv: false, hue: '#F5A524', meta: '4K · 44b · fusion'    },
  { id: '0039_mint',     name: 'reel · 0039 · mint',     tier: 'free',       priv: false, hue: '#6FFFE9', meta: '1080p · 24b · demo'   },
];

// ----- Privacy o-ring toggle with 0.5s phase-shift -----
function PrivacyToggle({ locked, onChange, size = 64 }) {
  const [phasing, setPhasing] = useState(false);
  const handle = () => {
    if (phasing) return;
    setPhasing(true);
    setTimeout(() => { onChange(!locked); }, 250); // mid-phase swap
    setTimeout(() => { setPhasing(false); }, 500);
  };
  const w = size, h = size * 0.54;
  const onTeal = locked ? false : true; // unlocked = teal (share), locked = orchid (private)
  return (
    <button onClick={handle}
      style={{
        width: w, height: h, borderRadius: 999, position: 'relative', cursor: 'pointer',
        border: 'none', padding: 0,
        background: onTeal
          ? 'linear-gradient(180deg,#003a47,#00B4D8)'
          : 'linear-gradient(180deg,#2a0d44,#7B2CBF)',
        boxShadow: onTeal
          ? 'inset 0 1px 0 rgba(255,255,255,0.25),inset 0 -1px 2px rgba(0,0,0,0.5),0 0 18px rgba(0,180,216,0.55),0 0 0 1px rgba(0,180,216,0.55)'
          : 'inset 0 1px 0 rgba(255,255,255,0.25),inset 0 -1px 2px rgba(0,0,0,0.5),0 0 18px rgba(123,44,191,0.55),0 0 0 1px rgba(166,91,224,0.55)',
        transition: 'background 500ms cubic-bezier(0.65,0,0.35,1), box-shadow 500ms cubic-bezier(0.65,0,0.35,1), transform 500ms cubic-bezier(0.65,0,0.35,1)',
        transform: phasing ? 'scale(0.96)' : 'scale(1)',
        filter: phasing ? 'brightness(1.4) saturate(1.3)' : 'none',
      }}
      aria-label={locked ? 'private — tap to share' : 'public — tap to lock'}>
      {/* inner gloss */}
      <span style={{ position: 'absolute', inset: '6% 8% auto 8%', height: '40%', borderRadius: 999,
                     background: 'linear-gradient(180deg,rgba(255,255,255,0.45),rgba(255,255,255,0))',
                     filter: 'blur(0.4px)', pointerEvents: 'none' }} />
      {/* puck with icon */}
      <span style={{
        position: 'absolute', top: '8%', bottom: '8%',
        left: onTeal ? `calc(100% - ${h * 0.84 + h * 0.08}px)` : `${h * 0.08}px`,
        width: h * 0.84, height: h * 0.84,
        borderRadius: 999,
        background: onTeal ? 'linear-gradient(180deg,#fff,#9be4f1)' : 'linear-gradient(180deg,#fff,#dab8f0)',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.6),inset 0 -1px 0 rgba(0,0,0,0.4),0 4px 10px rgba(0,0,0,0.6)',
        transition: 'left 500ms cubic-bezier(0.65,0,0.35,1), background 500ms cubic-bezier(0.65,0,0.35,1)',
        display: 'grid', placeItems: 'center',
        color: onTeal ? '#001a22' : '#2a0d44',
        fontFamily: 'JetBrains Mono,monospace', fontSize: h * 0.34, fontWeight: 700,
      }}>
        {onTeal ? '◉' : '⌬'}
      </span>
    </button>
  );
}

// ----- Asset tile -----
function VaultTile({ a, viewerTier, onPrivacyChange, onShare }) {
  const tier = TIERS[a.tier];
  const order = TIER_ORDER.indexOf(a.tier);
  const viewerOrder = TIER_ORDER.indexOf(viewerTier);
  const locked = order > viewerOrder;
  return (
    <div style={{
      position: 'relative', borderRadius: 18, overflow: 'hidden', isolation: 'isolate',
      background: 'linear-gradient(180deg,#1d1d22,#0a0a0c)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.10),inset 0 -1px 0 rgba(0,0,0,0.55),0 14px 36px rgba(0,0,0,0.6),0 0 0 1px rgba(255,255,255,0.05)',
    }}>
      {/* thumb */}
      <div style={{
        height: 180, position: 'relative',
        background: `radial-gradient(60% 80% at 30% 80%, ${a.hue}cc, transparent 70%), radial-gradient(50% 60% at 80% 20%, rgba(123,44,191,0.4), transparent 70%), #08080a`,
        filter: locked ? 'blur(14px) saturate(0.6)' : 'none',
        transition: 'filter 420ms cubic-bezier(0.65,0,0.35,1)',
      }}>
        {/* corner ticks */}
        <span style={{ position:'absolute', top:10, left:10, width:14, height:14, border:'1px solid rgba(0,180,216,0.6)', borderRight:'none', borderBottom:'none' }} />
        <span style={{ position:'absolute', top:10, right:10, width:14, height:14, border:'1px solid rgba(0,180,216,0.6)', borderLeft:'none', borderBottom:'none' }} />
        <span style={{ position:'absolute', bottom:10, left:10, width:14, height:14, border:'1px solid rgba(0,180,216,0.6)', borderRight:'none', borderTop:'none' }} />
        <span style={{ position:'absolute', bottom:10, right:10, width:14, height:14, border:'1px solid rgba(0,180,216,0.6)', borderLeft:'none', borderTop:'none' }} />
      </div>

      {/* lock overlay */}
      {locked && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          gap: 8, background: 'linear-gradient(180deg, rgba(8,8,10,0.4), rgba(8,8,10,0.85))',
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: 999,
            background: `radial-gradient(80% 80% at 50% 22%,rgba(255,255,255,0.5),transparent 60%), radial-gradient(120% 120% at 50% 100%,${tier.color}88,transparent 70%), linear-gradient(180deg,#34343B,#08080a)`,
            boxShadow: `inset 0 1px 0 rgba(255,255,255,0.4),inset 0 -1px 0 rgba(0,0,0,0.7),0 0 0 1px ${tier.color}55,0 0 18px ${tier.color}44`,
            display: 'grid', placeItems: 'center', color: tier.color, fontFamily: 'JetBrains Mono,monospace', fontSize: 18,
          }}>⌬</div>
          <div style={{ fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 10, letterSpacing: '0.32em', textTransform: 'uppercase', color: tier.color }}>
            {tier.label} only · {tier.max}
          </div>
        </div>
      )}

      {/* meta */}
      <div style={{ padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: 12, letterSpacing: '0.06em', color: '#F4F4F7' }}>{a.name}</span>
          <span style={{
            fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
            padding: '3px 8px', borderRadius: 999, color: tier.color, border: `1px solid ${tier.color}55`, background: tier.accent,
          }}>{tier.label} · {tier.max}</span>
        </div>
        <div style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.10em', color: '#6E6E7A', textTransform: 'uppercase' }}>{a.meta}</div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <PrivacyToggle locked={a.priv} onChange={(v) => onPrivacyChange(a.id, v)} />
            <span style={{ fontFamily: 'Orbitron,sans-serif', fontWeight: 600, fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', color: a.priv ? '#D4A8F0' : '#7DDCEE' }}>
              {a.priv ? 'Private' : 'Public'}
            </span>
          </div>
          <button
            onClick={() => onShare(a)}
            disabled={locked || a.priv}
            style={{
              fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase',
              padding: '8px 14px', borderRadius: 999, border: 'none', cursor: (locked || a.priv) ? 'not-allowed' : 'pointer',
              color: (locked || a.priv) ? '#3F3F48' : '#001a22',
              background: (locked || a.priv) ? 'linear-gradient(180deg,#1B1B1E,#0a0a0c)' : 'linear-gradient(180deg,#18C9EF,#00637A)',
              boxShadow: (locked || a.priv)
                ? 'inset 0 1px 0 rgba(255,255,255,0.05),0 0 0 1px rgba(255,255,255,0.05)'
                : 'inset 0 1px 0 rgba(255,255,255,0.4),inset 0 -1px 0 rgba(0,0,0,0.5),0 0 16px rgba(0,180,216,0.4)',
            }}>
            Share ▸
          </button>
        </div>
      </div>
    </div>
  );
}

// ----- Air Radio widget — circular HUD, mint glow, audio-reactive -----
function AirRadio() {
  const canvasRef = useRef(null);
  const [playing, setPlaying] = useState(true);
  useEffect(() => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height, cx = W/2, cy = H/2;
    let t = 0, raf;
    // Simulated audio peaks (no real stream wired — see notes)
    const peaks = new Array(64).fill(0).map(() => Math.random());
    const tick = () => {
      t += 0.016;
      ctx.clearRect(0,0,W,H);
      // halo
      const halo = ctx.createRadialGradient(cx,cy,40, cx,cy,W*0.55);
      halo.addColorStop(0,'rgba(111,255,233,0.18)');
      halo.addColorStop(1,'rgba(111,255,233,0)');
      ctx.fillStyle = halo; ctx.fillRect(0,0,W,H);
      // body ring
      ctx.beginPath(); ctx.arc(cx,cy, 78, 0, Math.PI*2);
      const grd = ctx.createLinearGradient(0,0,0,H);
      grd.addColorStop(0,'#34343B'); grd.addColorStop(1,'#08080a');
      ctx.fillStyle = grd; ctx.fill();
      ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(111,255,233,0.5)'; ctx.stroke();
      // inner well
      ctx.beginPath(); ctx.arc(cx,cy, 44, 0, Math.PI*2);
      ctx.fillStyle = '#08080a'; ctx.fill();
      // 64 audio bars around the ring
      const N = 64;
      for (let i = 0; i < N; i++) {
        const a = (i / N) * Math.PI * 2 - Math.PI/2;
        const peak = playing
          ? Math.abs(Math.sin(t * 1.6 + i * 0.4)) * 0.7 + Math.random() * 0.3
          : 0.05;
        peaks[i] = peaks[i] * 0.7 + peak * 0.3;
        const r0 = 56, r1 = 56 + peaks[i] * 18;
        const x0 = cx + Math.cos(a) * r0, y0 = cy + Math.sin(a) * r0;
        const x1 = cx + Math.cos(a) * r1, y1 = cy + Math.sin(a) * r1;
        ctx.strokeStyle = `rgba(111,255,233,${0.35 + peaks[i] * 0.6})`;
        ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(x0,y0); ctx.lineTo(x1,y1); ctx.stroke();
      }
      // glow rim — pulses with average peak
      const avg = peaks.reduce((s,v)=>s+v,0) / N;
      ctx.shadowColor = '#6FFFE9'; ctx.shadowBlur = 18 + avg * 30;
      ctx.beginPath(); ctx.arc(cx,cy, 78, 0, Math.PI*2);
      ctx.strokeStyle = `rgba(111,255,233,${0.4 + avg * 0.5})`; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.shadowBlur = 0;
      // play glyph
      ctx.fillStyle = '#6FFFE9';
      if (playing) {
        ctx.fillRect(cx-8, cy-10, 5, 20);
        ctx.fillRect(cx+3, cy-10, 5, 20);
      } else {
        ctx.beginPath(); ctx.moveTo(cx-7,cy-10); ctx.lineTo(cx-7,cy+10); ctx.lineTo(cx+10,cy); ctx.closePath(); ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => cancelAnimationFrame(raf);
  }, [playing]);
  return (
    <div style={{
      position: 'fixed', right: 26, bottom: 26, width: 220, padding: 12, borderRadius: 22,
      background: 'linear-gradient(180deg,#15151a,#0a0a0c)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.10),0 14px 36px rgba(0,0,0,0.7),0 0 0 1px rgba(111,255,233,0.18),0 0 36px rgba(111,255,233,0.18)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, zIndex: 50,
    }}>
      <canvas ref={canvasRef} width={196} height={196}
              onClick={() => setPlaying(p => !p)}
              style={{ display: 'block', cursor: 'pointer', borderRadius: 999 }} />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
        <span style={{ fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 10, letterSpacing: '0.32em', textTransform: 'uppercase', color: '#6FFFE9' }}>
          Air Radio · live
        </span>
        <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.10em', color: '#6E6E7A', textTransform: 'uppercase' }}>
          stream · q44.fm/air
        </span>
      </div>
    </div>
  );
}

window.PrivacyToggle = PrivacyToggle;
window.VaultTile = VaultTile;
window.AirRadio = AirRadio;
window.TIERS = TIERS;
window.TIER_ORDER = TIER_ORDER;
window.ASSETS = ASSETS;
