/* global React */
const { useState, useMemo } = React;

// ============================================================
// Soul Engine Console — Q44 UI kit components
// All components stick to colors_and_type.css tokens.
// ============================================================

// ---------- Sidebar ----------
function Sidebar({ active, onSelect }) {
  const items = [
    { id: 'render',  label: 'Render',     hint: '128/256',  icon: '◎' },
    { id: 'soul',    label: 'Soul Pass',  hint: 'sss 0.86', icon: '⊙' },
    { id: 'reels',   label: 'Reels',      hint: '12 reels', icon: '▣' },
    { id: 'lens',    label: 'Lens Lab',   hint: '3 active', icon: '◇' },
    { id: 'archive', label: 'Archive',    hint: '044 vols', icon: '◫' },
  ];
  return (
    <aside style={sbStyles.aside}>
      <div style={sbStyles.brand}>
        <div style={sbStyles.mark} />
        <div>
          <div style={sbStyles.brandTop}>Q44 · SOUL</div>
          <div style={sbStyles.brandSub}>console / 0.44.2</div>
        </div>
      </div>

      <div style={sbStyles.section}>NAVIGATION</div>
      <nav style={sbStyles.nav}>
        {items.map(it => (
          <button
            key={it.id}
            onClick={() => onSelect && onSelect(it.id)}
            style={{ ...sbStyles.item, ...(active === it.id ? sbStyles.itemOn : {}) }}>
            <span style={sbStyles.ico}>{it.icon}</span>
            <span style={{ flex: 1, textAlign: 'left' }}>
              <div style={sbStyles.itemLbl}>{it.label}</div>
              <div style={sbStyles.itemSub}>{it.hint}</div>
            </span>
            {active === it.id && <span style={sbStyles.activeRail} />}
          </button>
        ))}
      </nav>

      <div style={sbStyles.section}>PIPELINE</div>
      <div style={sbStyles.pipeline}>
        <div style={sbStyles.pipeRow}><span style={sbStyles.pipeLbl}>Depth</span><span style={sbStyles.pipeVal}>44 b</span></div>
        <div style={sbStyles.pipeRow}><span style={sbStyles.pipeLbl}>SSS</span><span style={sbStyles.pipeVal}>0.86</span></div>
        <div style={sbStyles.pipeRow}><span style={sbStyles.pipeLbl}>Env</span><span style={sbStyles.pipeVal}>astro-noir</span></div>
      </div>

      <div style={sbStyles.foot}>
        <div style={sbStyles.userOring}>K</div>
        <div>
          <div style={sbStyles.userName}>K. Knocks</div>
          <div style={sbStyles.userRole}>Studio · Lead</div>
        </div>
      </div>
    </aside>
  );
}

const sbStyles = {
  aside: { width: 260, minHeight: '100%', background: 'linear-gradient(180deg,#15151a,#0a0a0c)',
           borderRight: '1px solid rgba(255,255,255,0.05)', padding: '20px 16px', display: 'flex',
           flexDirection: 'column', gap: 14 },
  brand: { display: 'flex', alignItems: 'center', gap: 12, padding: '0 4px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)' },
  mark:  { width: 36, height: 36, borderRadius: 999,
           background: 'radial-gradient(80% 80% at 50% 22%,rgba(255,255,255,0.4) 0%,rgba(255,255,255,0.05) 32%,transparent 60%),radial-gradient(120% 120% at 50% 100%,rgba(0,180,216,0.5) 0%,transparent 70%),radial-gradient(120% 120% at 50% 0%,#34343B 0%,#1B1B1E 50%,#08080a 100%)',
           boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.3),inset 0 -1px 0 rgba(0,0,0,0.7),0 0 0 1px rgba(0,180,216,0.35),0 0 16px rgba(0,180,216,0.25)' },
  brandTop: { fontFamily: 'Orbitron,sans-serif', fontWeight: 800, fontSize: 13, letterSpacing: '0.18em', color: '#F4F4F7' },
  brandSub: { fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.1em', color: '#6E6E7A', textTransform: 'uppercase' },

  section: { fontFamily: 'JetBrains Mono,monospace', fontSize: 9, letterSpacing: '0.32em', color: '#6E6E7A',
             padding: '8px 4px 4px' },
  nav: { display: 'flex', flexDirection: 'column', gap: 2 },
  item: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10,
          background: 'transparent', border: 'none', color: '#B7B7C2', cursor: 'pointer', position: 'relative',
          transition: '160ms cubic-bezier(0.2,0.8,0.2,1)' },
  itemOn: { background: 'linear-gradient(90deg,rgba(0,180,216,0.10),rgba(0,180,216,0))', color: '#F4F4F7' },
  activeRail: { position: 'absolute', left: 0, top: 8, bottom: 8, width: 2, background: '#00B4D8',
                boxShadow: '0 0 10px #00B4D8', borderRadius: 2 },
  ico: { width: 28, height: 28, borderRadius: 8, display: 'grid', placeItems: 'center',
         background: 'linear-gradient(180deg,#2c2c33,#16161a)',
         boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.12),inset 0 -1px 0 rgba(0,0,0,0.5)',
         color: '#4FD1E8', fontFamily: 'JetBrains Mono,monospace', fontSize: 13 },
  itemLbl: { fontFamily: 'Orbitron,sans-serif', fontWeight: 600, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase' },
  itemSub: { fontFamily: 'JetBrains Mono,monospace', fontSize: 9, letterSpacing: '0.1em', color: '#6E6E7A', textTransform: 'uppercase' },

  pipeline: { display: 'flex', flexDirection: 'column', gap: 6, padding: '4px 8px' },
  pipeRow:  { display: 'flex', justifyContent: 'space-between', fontFamily: 'JetBrains Mono,monospace', fontSize: 11 },
  pipeLbl:  { color: '#6E6E7A', letterSpacing: '0.14em', textTransform: 'uppercase' },
  pipeVal:  { color: '#F4F4F7' },

  foot: { marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 10, padding: '12px 8px 0',
          borderTop: '1px solid rgba(255,255,255,0.05)' },
  userOring: { width: 36, height: 36, borderRadius: 999,
               background: 'radial-gradient(120% 120% at 50% 0%,#A65BE0 0%,#7B2CBF 50%,#3F1668 100%)',
               boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.4),inset 0 -1px 0 rgba(0,0,0,0.6),0 0 0 1px rgba(166,91,224,0.5)',
               display: 'grid', placeItems: 'center', fontFamily: 'Orbitron,sans-serif', fontWeight: 700,
               color: '#f6ecff', fontSize: 14 },
  userName: { fontFamily: 'Space Grotesk,sans-serif', fontWeight: 600, fontSize: 13, color: '#F4F4F7' },
  userRole: { fontFamily: 'JetBrains Mono,monospace', fontSize: 9, letterSpacing: '0.16em', color: '#6E6E7A', textTransform: 'uppercase' },
};

// ---------- Topbar ----------
function Topbar({ title = 'Render', subtitle = 'reel_0044_soul' }) {
  return (
    <header style={tbStyles.bar}>
      <div style={tbStyles.left}>
        <div style={tbStyles.eyebrow}>Q44 / SOUL.engine</div>
        <h1 style={tbStyles.title}>{title}</h1>
      </div>
      <div style={tbStyles.right}>
        <span style={tbStyles.id}>● {subtitle}</span>
        <button className="q-oring q-oring--ghost" style={tbStyles.ghostBtn}>Hold</button>
        <button className="q-oring q-oring--teal" style={tbStyles.tealBtn}>Render Reel</button>
      </div>
    </header>
  );
}

const tbStyles = {
  bar: { display: 'flex', alignItems: 'center', justifyContent: 'space-between',
         padding: '20px 32px', borderBottom: '1px solid rgba(255,255,255,0.05)',
         background: 'linear-gradient(180deg,rgba(255,255,255,0.02),transparent)' },
  left: { display: 'flex', flexDirection: 'column', gap: 6 },
  eyebrow: { fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.32em', color: '#00B4D8',
             textTransform: 'uppercase', lineHeight: 1 },
  title: { fontFamily: 'Orbitron,sans-serif', fontWeight: 800, fontSize: 28, lineHeight: 1, letterSpacing: '0.06em',
           textTransform: 'uppercase', color: '#F4F4F7', margin: 0 },
  right: { display: 'flex', alignItems: 'center', gap: 12 },
  id: { fontFamily: 'JetBrains Mono,monospace', fontSize: 11, letterSpacing: '0.14em', color: '#7DDCEE',
        textTransform: 'uppercase', padding: '6px 12px', border: '1px solid rgba(0,180,216,0.3)',
        borderRadius: 6, background: 'rgba(0,180,216,0.06)' },
  ghostBtn: { fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 11, letterSpacing: '0.18em',
              textTransform: 'uppercase', padding: '10px 18px', cursor: 'pointer', border: 'none',
              color: '#B7B7C2' },
  tealBtn: { fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 12, letterSpacing: '0.16em',
             textTransform: 'uppercase', padding: '12px 22px', cursor: 'pointer', border: 'none',
             color: '#001a22' },
};

window.Sidebar = Sidebar;
window.Topbar = Topbar;
