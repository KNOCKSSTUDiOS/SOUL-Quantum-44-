/* global React */
const { useState, useEffect, useRef } = React;

// ============================================================
// Render console — main work area for the Soul Engine
// ============================================================

function Viewport({ progress = 0.5, status = 'rendering' }) {
  const canvasRef = useRef(null);
  // Animated drifting noise rectangle to feel "live"
  useEffect(() => {
    let raf;
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    const w = c.width, h = c.height;
    const tick = (t) => {
      // base
      ctx.fillStyle = '#08080a';
      ctx.fillRect(0, 0, w, h);
      // teal pool
      const g1 = ctx.createRadialGradient(w*0.35, h*0.7, 10, w*0.35, h*0.7, w*0.5);
      g1.addColorStop(0, 'rgba(0,180,216,0.55)');
      g1.addColorStop(1, 'rgba(0,180,216,0)');
      ctx.fillStyle = g1; ctx.fillRect(0,0,w,h);
      // orchid pool
      const g2 = ctx.createRadialGradient(w*0.75, h*0.25, 10, w*0.75, h*0.25, w*0.5);
      g2.addColorStop(0, 'rgba(123,44,191,0.5)');
      g2.addColorStop(1, 'rgba(123,44,191,0)');
      ctx.fillStyle = g2; ctx.fillRect(0,0,w,h);
      // grain
      const id = ctx.getImageData(0, 0, w, h);
      for (let i = 0; i < id.data.length; i += 4) {
        const n = (Math.random() - 0.5) * 22;
        id.data[i]   = Math.max(0, Math.min(255, id.data[i]   + n));
        id.data[i+1] = Math.max(0, Math.min(255, id.data[i+1] + n));
        id.data[i+2] = Math.max(0, Math.min(255, id.data[i+2] + n));
      }
      ctx.putImageData(id, 0, 0);
      // scanline sweep
      const y = ((t / 30) % h);
      ctx.fillStyle = 'rgba(0,180,216,0.08)';
      ctx.fillRect(0, y, w, 2);
      raf = requestAnimationFrame(tick);
    };
    tick(0);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div style={vpStyles.wrap}>
      <canvas ref={canvasRef} width={720} height={400} style={vpStyles.canvas} />
      <div style={vpStyles.cornerTL} />
      <div style={vpStyles.cornerTR} />
      <div style={vpStyles.cornerBL} />
      <div style={vpStyles.cornerBR} />
      <div style={vpStyles.recDot}>
        <span style={vpStyles.dot} />REC ● Q44
      </div>
      <div style={vpStyles.metaTR}>2.39 : 1 · 24p · 44b</div>
      <div style={vpStyles.bottomBar}>
        <div style={vpStyles.frame}>FRAME 0128 / 0256</div>
        <div style={vpStyles.scrubTrack}>
          <div style={{ ...vpStyles.scrubFill, width: `${progress * 100}%` }} />
          <div style={{ ...vpStyles.scrubHandle, left: `calc(${progress * 100}% - 9px)` }} />
        </div>
        <div style={vpStyles.tc}>00:00:05:08</div>
      </div>
    </div>
  );
}

const vpStyles = {
  wrap: { position: 'relative', borderRadius: 16, overflow: 'hidden',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.10),0 14px 36px rgba(0,0,0,0.7),0 0 0 1px rgba(255,255,255,0.06)',
          aspectRatio: '2.39 / 1' },
  canvas: { display: 'block', width: '100%', height: '100%' },
  cornerTL: { position: 'absolute', top: 12, left: 12, width: 16, height: 16, border: '1px solid rgba(0,180,216,0.7)', borderRight: 'none', borderBottom: 'none' },
  cornerTR: { position: 'absolute', top: 12, right: 12, width: 16, height: 16, border: '1px solid rgba(0,180,216,0.7)', borderLeft: 'none', borderBottom: 'none' },
  cornerBL: { position: 'absolute', bottom: 12, left: 12, width: 16, height: 16, border: '1px solid rgba(0,180,216,0.7)', borderRight: 'none', borderTop: 'none' },
  cornerBR: { position: 'absolute', bottom: 12, right: 12, width: 16, height: 16, border: '1px solid rgba(0,180,216,0.7)', borderLeft: 'none', borderTop: 'none' },
  recDot: { position: 'absolute', top: 18, left: 36, fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.18em', color: '#FF8FA3', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 999, background: '#F43F5E', boxShadow: '0 0 8px #F43F5E', animation: 'pulse 1.6s infinite' },
  metaTR: { position: 'absolute', top: 18, right: 36, fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.18em', color: '#7DDCEE', textTransform: 'uppercase' },
  bottomBar: { position: 'absolute', left: 36, right: 36, bottom: 18, display: 'flex', alignItems: 'center', gap: 14 },
  frame: { fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.18em', color: '#F4F4F7', textTransform: 'uppercase' },
  scrubTrack: { flex: 1, height: 4, borderRadius: 999, background: 'rgba(0,0,0,0.5)', position: 'relative', boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.7)' },
  scrubFill: { position: 'absolute', left: 0, top: 0, bottom: 0, borderRadius: 999, background: 'linear-gradient(90deg,#007A93,#00B4D8)', boxShadow: '0 0 12px rgba(0,180,216,0.7)' },
  scrubHandle: { position: 'absolute', top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, borderRadius: 999, background: 'linear-gradient(180deg,#fff,#9be4f1)', boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.6),0 4px 10px rgba(0,0,0,0.6),0 0 0 1px rgba(0,180,216,0.5)' },
  tc: { fontFamily: 'JetBrains Mono,monospace', fontSize: 11, letterSpacing: '0.14em', color: '#7DDCEE' },
};

function StatRail() {
  const stats = [
    { lbl: 'DEPTH',   val: '44b',     sub: 'neural' },
    { lbl: 'SSS',     val: '0.86',    sub: 'subsurface' },
    { lbl: 'ENV',     val: 'NOIR',    sub: 'astro' },
    { lbl: 'LATENCY', val: '12.4ms',  sub: 'wire' },
  ];
  return (
    <div style={srStyles.row}>
      {stats.map((s) => (
        <div key={s.lbl} style={srStyles.cell}>
          <div style={srStyles.lbl}>{s.lbl}</div>
          <div style={srStyles.val}>{s.val}</div>
          <div style={srStyles.sub}>{s.sub}</div>
        </div>
      ))}
    </div>
  );
}

const srStyles = {
  row: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10 },
  cell: { padding: '14px 16px', borderRadius: 14,
          background: 'linear-gradient(180deg,#1d1d22,#0E0E11)',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.10),inset 0 -1px 0 rgba(0,0,0,0.5),0 0 0 1px rgba(255,255,255,0.05)' },
  lbl: { fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.18em', color: '#6E6E7A', textTransform: 'uppercase' },
  val: { fontFamily: 'Orbitron,sans-serif', fontWeight: 800, fontSize: 26, letterSpacing: '0.04em', color: '#F4F4F7', marginTop: 2 },
  sub: { fontFamily: 'JetBrains Mono,monospace', fontSize: 10, letterSpacing: '0.14em', color: '#4FD1E8', textTransform: 'uppercase', marginTop: 2 },
};

function ReelList() {
  const reels = [
    { id: 'reel_0044_soul',      st: 'render',  meta: '128/256 · 0.412s', live: true },
    { id: 'reel_0043_orchid',    st: 'soul',    meta: '256/256 · graded',  live: false },
    { id: 'reel_0042_noir',      st: 'idle',    meta: 'archived · 11d',    live: false },
    { id: 'reel_0041_meltdown',  st: 'fault',   meta: 'depth mismatch',    live: false },
  ];
  const palette = {
    render: { bg: 'rgba(0,180,216,0.10)', bd: 'rgba(0,180,216,0.4)', fg: '#7DDCEE', lbl: 'Rendering' },
    soul:   { bg: 'rgba(123,44,191,0.14)', bd: 'rgba(166,91,224,0.45)', fg: '#D4A8F0', lbl: 'Soul-graded' },
    idle:   { bg: 'rgba(255,255,255,0.04)', bd: 'rgba(255,255,255,0.08)', fg: '#B7B7C2', lbl: 'Idle' },
    fault:  { bg: 'rgba(244,63,94,0.14)', bd: 'rgba(244,63,94,0.45)', fg: '#FF8FA3', lbl: 'Fault' },
  };
  return (
    <div style={rlStyles.list}>
      <div style={rlStyles.header}>
        <span>Reel</span><span>Status</span><span>Meta</span><span></span>
      </div>
      {reels.map((r) => {
        const p = palette[r.st];
        return (
          <div key={r.id} style={rlStyles.row}>
            <div style={rlStyles.id}>
              <span style={{ ...rlStyles.thumb, background: r.st === 'soul' ? 'linear-gradient(135deg,#7B2CBF,#3F1668)' : r.st === 'render' ? 'linear-gradient(135deg,#00B4D8,#00637A)' : r.st === 'fault' ? 'linear-gradient(135deg,#F43F5E,#7a1224)' : 'linear-gradient(135deg,#34343B,#1B1B1E)' }} />
              {r.id}
            </div>
            <div style={{ ...rlStyles.chip, background: p.bg, borderColor: p.bd, color: p.fg }}>
              {r.live && <span style={{ ...rlStyles.pulse, background: p.fg, boxShadow: `0 0 8px ${p.fg}` }} />}
              {p.lbl}
            </div>
            <div style={rlStyles.meta}>{r.meta}</div>
            <button style={rlStyles.action}>OPEN ▸</button>
          </div>
        );
      })}
    </div>
  );
}

const rlStyles = {
  list: { borderRadius: 16, overflow: 'hidden',
          background: 'linear-gradient(180deg,#15151a,#0a0a0c)',
          boxShadow: '0 0 0 1px rgba(255,255,255,0.05),0 14px 36px rgba(0,0,0,0.6)' },
  header: { display: 'grid', gridTemplateColumns: '2fr 1fr 1.5fr 110px', gap: 12, padding: '10px 18px',
            fontFamily: 'JetBrains Mono,monospace', fontSize: 9, letterSpacing: '0.32em', color: '#6E6E7A',
            textTransform: 'uppercase', borderBottom: '1px solid rgba(255,255,255,0.05)' },
  row: { display: 'grid', gridTemplateColumns: '2fr 1fr 1.5fr 110px', gap: 12, padding: '14px 18px', alignItems: 'center',
         borderBottom: '1px solid rgba(255,255,255,0.04)' },
  id: { display: 'flex', alignItems: 'center', gap: 12, fontFamily: 'JetBrains Mono,monospace', fontSize: 12, color: '#F4F4F7', letterSpacing: '0.06em' },
  thumb: { width: 28, height: 28, borderRadius: 6, boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.2),inset 0 -1px 0 rgba(0,0,0,0.5)' },
  chip: { fontFamily: 'Orbitron,sans-serif', fontWeight: 600, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase',
          padding: '5px 10px', borderRadius: 999, border: '1px solid', display: 'inline-flex', alignItems: 'center', gap: 6, justifySelf: 'start' },
  pulse: { width: 7, height: 7, borderRadius: 999 },
  meta: { fontFamily: 'JetBrains Mono,monospace', fontSize: 11, color: '#6E6E7A', letterSpacing: '0.06em' },
  action: { fontFamily: 'Orbitron,sans-serif', fontWeight: 700, fontSize: 10, letterSpacing: '0.18em', color: '#4FD1E8',
            background: 'transparent', border: 'none', cursor: 'pointer' },
};

window.Viewport = Viewport;
window.StatRail = StatRail;
window.ReelList = ReelList;
